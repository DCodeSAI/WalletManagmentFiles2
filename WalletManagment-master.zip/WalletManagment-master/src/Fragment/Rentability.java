package Fragment;

public class Rentability {
}
