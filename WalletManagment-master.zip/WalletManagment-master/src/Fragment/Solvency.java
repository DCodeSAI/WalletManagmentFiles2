package Fragment;

public class Solvency {
}
