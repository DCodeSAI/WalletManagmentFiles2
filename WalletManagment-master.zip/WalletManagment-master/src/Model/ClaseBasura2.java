package Model;

public class ClaseBasura2 {
}
